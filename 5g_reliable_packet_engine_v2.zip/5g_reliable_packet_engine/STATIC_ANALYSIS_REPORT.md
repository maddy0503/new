# Static and Dynamic Analysis Status

Status reflects the tools that were actually available in the packaging environment. Do not read "NOT RUN" as "passing".

| Tool | Command | Result in this workspace |
|---|---|---|
| GCC warning build | `make -B` | PASS - no warnings (`-Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wstrict-prototypes`) |
| GCC extended sweep | `gcc -fsyntax-only` with `-Wcast-qual -Wnull-dereference -Wduplicated-cond -Wduplicated-branches -Wlogical-op -Wformat=2 -Wundef -Wmissing-prototypes -Wjump-misses-init -Wunused-macros` on `src/` and `tests/` | PASS - 0 findings |
| GCC static analyzer | `gcc -fanalyzer` on `src/*.c` | PASS - 0 findings |
| C unit tests | `make test` | PASS - 285 test cases, 1315 checks, 0 failures |
| AddressSanitizer + UBSan | `make sanitize` | PASS - all five C test binaries clean |
| ThreadSanitizer (ad-hoc) | 4 parallel timestamped simulations | PASS - no races |
| gcov coverage | `make coverage` | 97.7 % line, 92.5 % branch, 100 % function |
| **Cppcheck** | `make cppcheck` | **NOT RUN - cppcheck is not installed here and the sandbox has no network.** See "Cppcheck fixes" below. |
| Valgrind / Helgrind | `make valgrind` / `make helgrind` | NOT RUN (not installed) |
| GoogleTest | `make gtest` | NOT RUN (not installed) |
| MISRA addon | `make misra` | NOT RUN (needs Cppcheck + licensed rule text) |

## Cppcheck fixes (applied without being able to execute cppcheck)
Cppcheck could not be executed, so these are corrections for the findings it is known to report on this kind of code, plus
a review of every file for its style/warning/performance/portability checks. **Please run `make cppcheck` and send me any
remaining output.**

| Finding class | Location | Fix |
|---|---|---|
| `unknownMacro` / syntax error on `TEST(...)` when GoogleTest headers are not visible (breaks the whole run, exit code 1) | `tests/gtest/*.cpp` via Makefile | `make cppcheck` now passes `--library=googletest`, `--suppress=missingInclude`, and no longer scans the gtest files twice |
| `constParameterPointer` (parameter can be pointer to const) | `main.c: do_search(app_t *)` | now `const app_t *` |
| `constParameterCallback` (unused `void *ctx` in a visitor callback) | `main.c: print_visitor` | the context is now a real row counter that is used |
| `knownConditionTrueFalse` (`CHECK(f != NULL)` inside `if (f == NULL)`) | new tests | tests use the pattern `CHECK(f != NULL); if (f == NULL) { return; }`; no `CHECK(1)` constants |
| `invalidPointerCast` | new test `bst_init_clears` | uses a real `bst_node_t` instead of casting `bst_t *` |
| Parameter name `clock` shadows a libc function | `logger.c/.h` | renamed `clock_fn` |
| Struct member `log` shadows libc `log()` | `main.c` | renamed `audit` |
| Thread-unsafe `localtime()`/`gmtime()` portability warning | `logger.c` | uses `localtime_r`/`gmtime_r` (POSIX) or `localtime_s`/`gmtime_s` (Windows) |

`config/cppcheck_suppressions.txt` is unchanged (`unusedFunction`, `missingIncludeSystem`).

## Run on Ubuntu / Debian
```sh
sudo apt update
sudo apt install build-essential cppcheck valgrind libgtest-dev
make clean && make test && make cppcheck && make sanitize && make gtest && make valgrind && make helgrind && make coverage
```
MISRA addon (optional): `make misra MISRA_RULES=/path/to/misra_c_2012_rules.txt`.

## Packet integrity feature
Packets include a 16-bit Fletcher-style checksum over sequence number, source/destination IDs, payload length and payload
bytes. The receiver validates it before delivery and rejects a corrupted packet with `STATUS_ERR_FORMAT`. This detects
accidental corruption only; it is not cryptographic authentication.
