/* input.h - bounded, validated console input helpers. */
#ifndef INPUT_H
#define INPUT_H

#include <stdio.h>
#include "common.h"

#define INPUT_MAX_ATTEMPTS 3U

typedef status_t (*input_text_validator_fn)(const char *text);

/* Reads one line with fgets (never gets). Strips CR/LF.
 * STATUS_ERR_IO on EOF/error, STATUS_ERR_RANGE if the line was longer than
 * the buffer (the remainder of the line is discarded). */
status_t input_read_line(FILE *in, char *buffer, size_t capacity);

/* Parses an unsigned decimal. Rejects empty text, signs, letters, trailing
 * characters and values outside [min, max]. */
status_t input_parse_u32(const char *text, uint32_t min, uint32_t max,
                         uint32_t *value);

/* Prompts up to INPUT_MAX_ATTEMPTS times. STATUS_ERR_IO means EOF. */
status_t input_prompt_u32(FILE *in, FILE *out, const char *prompt,
                          uint32_t min, uint32_t max, uint32_t *value);
status_t input_prompt_text(FILE *in, FILE *out, const char *prompt,
                           char *buffer, size_t capacity,
                           input_text_validator_fn validator);

#endif /* INPUT_H */
