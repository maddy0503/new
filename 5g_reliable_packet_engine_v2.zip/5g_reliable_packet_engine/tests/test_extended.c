/* test_extended.c - extended regression suite: stations, input, BST, packets,
 * Go-Back-N and storage. Every TEST case below is an independent function. */
#include <stdlib.h>
#include <string.h>
#include "test_framework.h"
#include "bst.h"
#include "input.h"
#include "sliding_window.h"
#include "storage.h"

#define SRC 101U
#define DST 202U
#define EXT_FILE "test_ext_stations.tmp.txt"

/* ------------------------------------------------------------------ helpers */
static station_t mk(station_id_t id)
{
    station_t s;
    (void)station_init(&s, id, "Stn", id % 1000U, 100U, 1U, "gNodeB");
    return s;
}

typedef struct { station_id_t ids[BST_MAX_STATIONS]; size_t n; } collect_t;
static void collect(const station_t *s, void *ctx)
{
    collect_t *c = (collect_t *)ctx;
    if (c->n < BST_MAX_STATIONS) { c->ids[c->n] = s->id; c->n++; }
}

static void build(bst_t *t, const station_id_t *ids, size_t n)
{
    size_t i;
    bst_init(t);
    for (i = 0U; i < n; i++) { station_t s = mk(ids[i]); (void)bst_insert(t, &s); }
}

static const station_id_t k_shape[7] = {50U, 30U, 70U, 20U, 40U, 60U, 80U};   /* insertion order */
static const station_id_t k_pre[7]   = {50U, 30U, 20U, 40U, 70U, 60U, 80U};   /* resulting preorder */

static bool order_is(const bst_t *t, bool pre, const station_id_t *want, size_t n)
{
    collect_t c; size_t i; bool same;
    c.n = 0U;
    same = ((pre ? bst_preorder(t, collect, &c) : bst_inorder(t, collect, &c)) == STATUS_OK) && (c.n == n);
    for (i = 0U; same && (i < n); i++) { same = (c.ids[i] == want[i]); }
    return same;
}

static void write_file(const char *path, const char *text)
{
    FILE *f = fopen(path, "w");
    if (f != NULL) { (void)fputs(text, f); (void)fclose(f); }
}

static sw_config_t scfg(uint8_t window, uint32_t packets)
{
    sw_config_t c;
    (void)sw_config_default(&c);
    c.window_size = window; c.packet_count = packets;
    c.data_loss_every = 0U; c.ack_loss_every = 0U;
    return c;
}

static packet_t mkpkt(uint8_t seq)
{
    packet_t p; const uint8_t pl[4] = {1U, 2U, 3U, 4U};
    (void)packet_init(&p, seq, SRC, DST, pl, sizeof(pl));
    return p;
}

#define TEST(name) static void name(void)

/* ===================== A. station validation (22) ========================= */
TEST(test_x_station_id_min_ok)        { station_t s; CHECK(station_init(&s, STATION_ID_MIN, "A", 0U, 0U, 1U, "T") == STATUS_OK); }
TEST(test_x_station_id_max_ok)        { station_t s; CHECK(station_init(&s, STATION_ID_MAX, "A", 0U, 0U, 1U, "T") == STATUS_OK); }
TEST(test_x_station_id_zero_bad)      { CHECK(station_validate_id(0U) == STATUS_ERR_RANGE); }
TEST(test_x_station_id_over_max_bad)  { CHECK(station_validate_id(STATION_ID_MAX + 1U) == STATUS_ERR_RANGE); }
TEST(test_x_station_id_uint_max_bad)  { CHECK(station_validate_id(UINT32_MAX) == STATUS_ERR_RANGE); }
TEST(test_x_name_one_char_ok)         { CHECK(station_validate_text("a", STATION_NAME_MAX) == STATUS_OK); }
TEST(test_x_name_31_chars_ok)         { char n[32]; (void)memset(n, 'z', 31U); n[31] = '\0'; CHECK(station_validate_text(n, STATION_NAME_MAX) == STATUS_OK); }
TEST(test_x_name_32_chars_bad)        { char n[40]; (void)memset(n, 'z', 32U); n[32] = '\0'; CHECK(station_validate_text(n, STATION_NAME_MAX) == STATUS_ERR_RANGE); }
TEST(test_x_type_15_chars_ok)         { char n[20]; (void)memset(n, 'q', 15U); n[15] = '\0'; CHECK(station_validate_text(n, STATION_TYPE_MAX) == STATUS_OK); }
TEST(test_x_type_16_chars_bad)        { char n[20]; (void)memset(n, 'q', 16U); n[16] = '\0'; CHECK(station_validate_text(n, STATION_TYPE_MAX) == STATUS_ERR_RANGE); }
TEST(test_x_text_digits_ok)           { CHECK(station_validate_text("0123456789", 32U) == STATUS_OK); }
TEST(test_x_text_punctuation_allowed) { CHECK(station_validate_text("a-b_c.d e", 32U) == STATUS_OK); }
TEST(test_x_text_inner_double_space)  { CHECK(station_validate_text("a  b", 32U) == STATUS_OK); }
TEST(test_x_text_only_space_bad)      { CHECK(station_validate_text(" ", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_text_tab_bad)             { CHECK(station_validate_text("a\tb", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_text_semicolon_bad)       { CHECK(station_validate_text("a;b", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_text_quote_bad)           { CHECK(station_validate_text("a\"b", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_text_slash_bad)           { CHECK(station_validate_text("a/b", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_text_high_byte_bad)       { CHECK(station_validate_text("a\xC3\xA9", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_text_trailing_space_bad)  { CHECK(station_validate_text("abc ", 32U) == STATUS_ERR_FORMAT); }
TEST(test_x_numbers_all_max_ok)       { CHECK(station_validate_numbers(STATION_DISTANCE_MAX, STATION_FARE_MAX, STATION_PLATFORM_MAX) == STATUS_OK); }
TEST(test_x_numbers_platform_zero_bad){ CHECK(station_validate_numbers(0U, 0U, 0U) == STATUS_ERR_RANGE); }

/* ===================== B. input parsing / prompts (24) ===================== */
static status_t pu(const char *t, uint32_t lo, uint32_t hi, uint32_t *v) { return input_parse_u32(t, lo, hi, v); }
TEST(test_x_parse_zero)              { uint32_t v = 9U; CHECK(pu("0", 0U, 10U, &v) == STATUS_OK && v == 0U); }
TEST(test_x_parse_leading_zeros)     { uint32_t v = 0U; CHECK(pu("007", 0U, 10U, &v) == STATUS_OK && v == 7U); }
TEST(test_x_parse_surrounding_blanks){ uint32_t v = 0U; CHECK(pu("  42\t ", 0U, 100U, &v) == STATUS_OK && v == 42U); }
TEST(test_x_parse_inner_space_bad)   { uint32_t v = 0U; CHECK(pu("4 2", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_plus_sign_bad)     { uint32_t v = 0U; CHECK(pu("+5", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_minus_sign_bad)    { uint32_t v = 0U; CHECK(pu("-0", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_hex_bad)           { uint32_t v = 0U; CHECK(pu("0x10", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_exponent_bad)      { uint32_t v = 0U; CHECK(pu("1e3", 0U, 5000U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_decimal_bad)       { uint32_t v = 0U; CHECK(pu("3.5", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_empty_bad)         { uint32_t v = 0U; CHECK(pu("", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_blank_only_bad)    { uint32_t v = 0U; CHECK(pu("  \t", 0U, 100U, &v) == STATUS_ERR_FORMAT); }
TEST(test_x_parse_below_min)         { uint32_t v = 77U; CHECK(pu("4", 5U, 9U, &v) == STATUS_ERR_RANGE && v == 77U); }
TEST(test_x_parse_above_max)         { uint32_t v = 77U; CHECK(pu("10", 5U, 9U, &v) == STATUS_ERR_RANGE && v == 77U); }
TEST(test_x_parse_exact_bounds)      { uint32_t v = 0U; CHECK(pu("5", 5U, 9U, &v) == STATUS_OK && pu("9", 5U, 9U, &v) == STATUS_OK && v == 9U); }
TEST(test_x_parse_uint32_max)        { uint32_t v = 0U; CHECK(pu("4294967295", 0U, UINT32_MAX, &v) == STATUS_OK && v == UINT32_MAX); }
TEST(test_x_parse_uint32_overflow)   { uint32_t v = 0U; CHECK(pu("4294967296", 0U, UINT32_MAX, &v) == STATUS_ERR_RANGE); }
TEST(test_x_parse_huge_digit_string) { uint32_t v = 0U; CHECK(pu("99999999999999999999999", 0U, UINT32_MAX, &v) == STATUS_ERR_RANGE); }
TEST(test_x_parse_failure_keeps_value){ uint32_t v = 123U; CHECK(pu("abc", 0U, 9U, &v) == STATUS_ERR_FORMAT && v == 123U); }
TEST(test_x_prompt_third_attempt_ok)
{
    FILE *in; FILE *out; uint32_t v = 0U;
    write_file(EXT_FILE, "x\n99\n5\n");
    in = fopen(EXT_FILE, "r"); out = fopen("test_ext_out.tmp.txt", "w");
    CHECK(in != NULL && out != NULL);
    if ((in != NULL) && (out != NULL)) { CHECK(input_prompt_u32(in, out, "n", 1U, 9U, &v) == STATUS_OK && v == 5U); }
    if (in != NULL) { (void)fclose(in); }
    if (out != NULL) { (void)fclose(out); }
    (void)remove(EXT_FILE); (void)remove("test_ext_out.tmp.txt");
}
TEST(test_x_prompt_three_failures_range)
{
    FILE *in; FILE *out; uint32_t v = 0U;
    write_file(EXT_FILE, "x\ny\nz\n5\n");
    in = fopen(EXT_FILE, "r"); out = fopen("test_ext_out.tmp.txt", "w");
    CHECK(in != NULL && out != NULL);
    if ((in != NULL) && (out != NULL)) { CHECK(input_prompt_u32(in, out, "n", 1U, 9U, &v) == STATUS_ERR_RANGE); }
    if (in != NULL) { (void)fclose(in); }
    if (out != NULL) { (void)fclose(out); }
    (void)remove(EXT_FILE); (void)remove("test_ext_out.tmp.txt");
}
TEST(test_x_prompt_eof_is_io)
{
    FILE *in; FILE *out; uint32_t v = 0U;
    write_file(EXT_FILE, "");
    in = fopen(EXT_FILE, "r"); out = fopen("test_ext_out.tmp.txt", "w");
    CHECK(in != NULL && out != NULL);
    if ((in != NULL) && (out != NULL)) { CHECK(input_prompt_u32(in, out, "n", 1U, 9U, &v) == STATUS_ERR_IO); }
    if (in != NULL) { (void)fclose(in); }
    if (out != NULL) { (void)fclose(out); }
    (void)remove(EXT_FILE); (void)remove("test_ext_out.tmp.txt");
}
TEST(test_x_prompt_null_arguments)
{
    uint32_t v = 0U;
    CHECK(input_prompt_u32(NULL, stdout, "n", 1U, 9U, &v) == STATUS_ERR_NULL);
    CHECK(input_prompt_u32(stdin, NULL, "n", 1U, 9U, &v) == STATUS_ERR_NULL);
    CHECK(input_prompt_u32(stdin, stdout, NULL, 1U, 9U, &v) == STATUS_ERR_NULL);
    CHECK(input_prompt_u32(stdin, stdout, "n", 1U, 9U, NULL) == STATUS_ERR_NULL);
}
TEST(test_x_read_line_capacity_limits)
{
    char b[8];
    CHECK(input_read_line(stdin, b, 1U) == STATUS_ERR_NULL);
    CHECK(input_read_line(stdin, b, 4097U) == STATUS_ERR_NULL);
    CHECK(input_read_line(stdin, NULL, 8U) == STATUS_ERR_NULL);
}

/* ===================== C. BST (24) ======================================== */
TEST(test_x_bst_init_null_safe)       { bst_t t; t.count = 5U; t.root = NULL; bst_init(NULL); CHECK(t.count == 5U); }
TEST(test_x_bst_init_clears)          { bst_t t; bst_node_t n; t.root = &n; t.count = 9U; bst_init(&t); CHECK(t.root == NULL && t.count == 0U); }
TEST(test_x_bst_insert_null_args)     { bst_t t; station_t s = mk(1U); bst_init(&t); CHECK(bst_insert(NULL, &s) == STATUS_ERR_NULL && bst_insert(&t, NULL) == STATUS_ERR_NULL); }
TEST(test_x_bst_insert_invalid_station){ bst_t t; station_t s = mk(1U); bst_init(&t); s.id = 0U; CHECK(bst_insert(&t, &s) == STATUS_ERR_RANGE && t.count == 0U); }
TEST(test_x_bst_inorder_sorted)       { bst_t t; const station_id_t want[7] = {20U, 30U, 40U, 50U, 60U, 70U, 80U}; build(&t, k_shape, 7U); CHECK(order_is(&t, false, want, 7U)); bst_destroy(&t); }
TEST(test_x_bst_preorder_shape)       { bst_t t; build(&t, k_shape, 7U); CHECK(order_is(&t, true, k_pre, 7U)); bst_destroy(&t); }
TEST(test_x_bst_count_after_inserts)  { bst_t t; build(&t, k_shape, 7U); CHECK(t.count == 7U); bst_destroy(&t); }
TEST(test_x_bst_duplicate_keeps_count){ bst_t t; station_t s = mk(50U); build(&t, k_shape, 7U); CHECK(bst_insert(&t, &s) == STATUS_ERR_DUPLICATE && t.count == 7U); bst_destroy(&t); }
TEST(test_x_bst_search_hit_and_miss)  { bst_t t; build(&t, k_shape, 7U); CHECK(bst_search(&t, 60U) != NULL && bst_search(&t, 61U) == NULL); bst_destroy(&t); }
TEST(test_x_bst_search_null_tree)     { CHECK(bst_search(NULL, 1U) == NULL); }
TEST(test_x_bst_search_empty_tree)    { bst_t t; bst_init(&t); CHECK(bst_search(&t, 1U) == NULL); }
TEST(test_x_bst_update_changes_fields)
{
    bst_t t; const station_t *f; build(&t, k_shape, 7U);
    CHECK(bst_update(&t, 40U, "New", 9U, 8U, 7U, "Core") == STATUS_OK);
    f = bst_search(&t, 40U);
    CHECK(f != NULL && strcmp(f->name, "New") == 0 && f->distance_km == 9U && f->fare == 8U && f->platform == 7U && strcmp(f->type, "Core") == 0);
    bst_destroy(&t);
}
TEST(test_x_bst_update_missing_id)    { bst_t t; build(&t, k_shape, 7U); CHECK(bst_update(&t, 999U, "N", 1U, 1U, 1U, "T") == STATUS_ERR_NOT_FOUND); bst_destroy(&t); }
TEST(test_x_bst_update_invalid_keeps_old)
{
    bst_t t; const station_t *f; build(&t, k_shape, 7U);
    CHECK(bst_update(&t, 40U, "bad|name", 1U, 1U, 1U, "T") == STATUS_ERR_FORMAT);
    f = bst_search(&t, 40U);
    CHECK(f != NULL && strcmp(f->name, "Stn") == 0);
    bst_destroy(&t);
}
TEST(test_x_bst_update_null_tree)     { CHECK(bst_update(NULL, 1U, "N", 1U, 1U, 1U, "T") == STATUS_ERR_NULL); }
TEST(test_x_bst_delete_leaf)          { bst_t t; const station_id_t want[6] = {50U, 30U, 40U, 70U, 60U, 80U}; build(&t, k_shape, 7U); CHECK(bst_delete(&t, 20U) == STATUS_OK && order_is(&t, true, want, 6U) && t.count == 6U); bst_destroy(&t); }
TEST(test_x_bst_delete_one_child_right)
{
    bst_t t; const station_id_t ids[3] = {10U, 5U, 15U}; const station_id_t extra = 20U; station_t s = mk(extra);
    const station_id_t want[3] = {10U, 5U, 20U};
    build(&t, ids, 3U); CHECK(bst_insert(&t, &s) == STATUS_OK);
    CHECK(bst_delete(&t, 15U) == STATUS_OK && order_is(&t, true, want, 3U));
    bst_destroy(&t);
}
TEST(test_x_bst_delete_one_child_left)
{
    bst_t t; const station_id_t ids[4] = {10U, 5U, 15U, 12U}; const station_id_t want[3] = {10U, 5U, 12U};
    build(&t, ids, 4U);
    CHECK(bst_delete(&t, 15U) == STATUS_OK && order_is(&t, true, want, 3U));
    bst_destroy(&t);
}
TEST(test_x_bst_delete_two_children_uses_successor) { bst_t t; const station_id_t want[6] = {60U, 30U, 20U, 40U, 70U, 80U}; build(&t, k_shape, 7U); CHECK(bst_delete(&t, 50U) == STATUS_OK && order_is(&t, true, want, 6U)); bst_destroy(&t); }
TEST(test_x_bst_delete_missing)       { bst_t t; build(&t, k_shape, 7U); CHECK(bst_delete(&t, 5U) == STATUS_ERR_NOT_FOUND && t.count == 7U); bst_destroy(&t); }
TEST(test_x_bst_delete_all_then_empty)
{
    bst_t t; size_t i; bool ok = true; build(&t, k_shape, 7U);
    for (i = 0U; i < 7U; i++) { if (bst_delete(&t, k_shape[i]) != STATUS_OK) { ok = false; } }
    CHECK(ok && t.count == 0U && t.root == NULL);
}
TEST(test_x_bst_stats_min_max)        { bst_t t; uint32_t n = 0U; station_id_t mn = 0U; station_id_t mx = 0U; build(&t, k_shape, 7U); CHECK(bst_stats(&t, &n, &mn, &mx) == STATUS_OK && n == 7U && mn == 20U && mx == 80U); bst_destroy(&t); }
TEST(test_x_bst_stats_empty_and_null) { bst_t t; uint32_t n = 5U; station_id_t mn = 5U; station_id_t mx = 5U; bst_init(&t); CHECK(bst_stats(&t, &n, &mn, &mx) == STATUS_ERR_EMPTY && n == 0U && mn == 0U && mx == 0U); CHECK(bst_stats(NULL, &n, &mn, &mx) == STATUS_ERR_NULL); }
TEST(test_x_bst_traversal_null_visitor){ bst_t t; bst_init(&t); CHECK(bst_inorder(&t, NULL, NULL) == STATUS_ERR_NULL && bst_preorder(&t, NULL, NULL) == STATUS_ERR_NULL && bst_inorder(NULL, collect, NULL) == STATUS_ERR_NULL); }
TEST(test_x_bst_destroy_resets)       { bst_t t; build(&t, k_shape, 7U); bst_destroy(&t); CHECK(t.root == NULL && t.count == 0U); bst_destroy(&t); bst_destroy(NULL); }
TEST(test_x_bst_descending_insert_chain) { bst_t t; station_id_t i; bool ok = true; bst_init(&t); for (i = 100U; i >= 1U; i--) { station_t s = mk(i); if (bst_insert(&t, &s) != STATUS_OK) { ok = false; } } CHECK(ok && t.count == 100U); bst_destroy(&t); }

/* ===================== D. packets, sequence numbers, queues (26) ========== */
TEST(test_x_seq_distance_same)        { CHECK(seq_distance(5U, 5U) == 0U && seq_distance(0U, 0U) == 0U); }
TEST(test_x_seq_distance_forward)     { CHECK(seq_distance(2U, 7U) == 5U); }
TEST(test_x_seq_distance_wrap)        { CHECK(seq_distance(15U, 0U) == 1U && seq_distance(14U, 1U) == 3U); }
TEST(test_x_seq_distance_backward)    { CHECK(seq_distance(3U, 2U) == 15U && seq_distance(0U, 15U) == 15U); }
TEST(test_x_seq_next_wraps)           { CHECK(seq_next(0U) == 1U && seq_next(14U) == 15U && seq_next(15U) == 0U); }
TEST(test_x_seq_next_full_cycle)      { uint8_t s = 0U; uint32_t i; for (i = 0U; i < SEQ_MODULUS; i++) { s = seq_next(s); } CHECK(s == 0U); }
TEST(test_x_packet_init_fields)       { packet_t p = mkpkt(9U); CHECK(p.seq == 9U && p.src == SRC && p.dst == DST && p.payload_len == 4U && p.status == PKT_STATUS_EMPTY && p.retry_count == 0U); }
TEST(test_x_packet_init_empty_payload){ packet_t p; CHECK(packet_init(&p, 1U, SRC, DST, NULL, 0U) == STATUS_OK && p.payload_len == 0U && packet_verify(&p)); }
TEST(test_x_packet_init_max_payload)  { packet_t p; uint8_t b[PAYLOAD_MAX]; (void)memset(b, 7, sizeof(b)); CHECK(packet_init(&p, 1U, SRC, DST, b, PAYLOAD_MAX) == STATUS_OK && p.payload_len == PAYLOAD_MAX); }
TEST(test_x_packet_init_bad_endpoint) { packet_t p; uint8_t b = 1U; CHECK(packet_init(&p, 0U, 0U, DST, &b, 1U) == STATUS_ERR_RANGE && packet_init(&p, 0U, SRC, STATION_ID_MAX + 1U, &b, 1U) == STATUS_ERR_RANGE); }
TEST(test_x_packet_verify_ok)         { packet_t p = mkpkt(3U); CHECK(packet_verify(&p)); }
TEST(test_x_packet_verify_null)       { CHECK(!packet_verify(NULL) && packet_checksum(NULL) == 0U); }
TEST(test_x_packet_detects_payload_flip) { packet_t p = mkpkt(3U); p.payload[2] ^= 0x01U; CHECK(!packet_verify(&p)); }
TEST(test_x_packet_detects_seq_change)   { packet_t p = mkpkt(3U); p.seq = 4U; CHECK(!packet_verify(&p)); }
TEST(test_x_packet_detects_src_change)   { packet_t p = mkpkt(3U); p.src++; CHECK(!packet_verify(&p)); }
TEST(test_x_packet_detects_dst_change)   { packet_t p = mkpkt(3U); p.dst++; CHECK(!packet_verify(&p)); }
TEST(test_x_packet_detects_len_change)   { packet_t p = mkpkt(3U); p.payload_len = 3U; CHECK(!packet_verify(&p)); }
TEST(test_x_packet_rejects_bad_len)      { packet_t p = mkpkt(3U); p.payload_len = (uint8_t)(PAYLOAD_MAX + 1U); CHECK(!packet_verify(&p) && packet_checksum(&p) == 0U); }
TEST(test_x_packet_checksum_deterministic){ packet_t a = mkpkt(5U); packet_t b = mkpkt(5U); CHECK(packet_checksum(&a) == packet_checksum(&b) && a.checksum == b.checksum); }
TEST(test_x_pktq_fifo_order)
{
    pkt_queue_t q; packet_t a = mkpkt(1U); packet_t b = mkpkt(2U); packet_t o;
    pktq_init(&q);
    CHECK(pktq_push(&q, &a, 0U) == STATUS_OK && pktq_push(&q, &b, 0U) == STATUS_OK);
    CHECK(pktq_pop_due(&q, 0U, &o) && o.seq == 1U && pktq_pop_due(&q, 0U, &o) && o.seq == 2U && !pktq_pop_due(&q, 0U, &o));
}
TEST(test_x_pktq_respects_due_tick)
{
    pkt_queue_t q; packet_t a = mkpkt(1U); packet_t o;
    pktq_init(&q); CHECK(pktq_push(&q, &a, 5U) == STATUS_OK);
    CHECK(!pktq_pop_due(&q, 4U, &o) && pktq_pop_due(&q, 5U, &o) && q.count == 0U);
}
TEST(test_x_pktq_full_at_capacity)
{
    pkt_queue_t q; packet_t a = mkpkt(1U); size_t i; bool ok = true;
    pktq_init(&q);
    for (i = 0U; i < CHANNEL_CAP; i++) { if (pktq_push(&q, &a, 0U) != STATUS_OK) { ok = false; } }
    CHECK(ok && pktq_push(&q, &a, 0U) == STATUS_ERR_FULL && q.count == CHANNEL_CAP);
}
TEST(test_x_pktq_wraparound)
{
    pkt_queue_t q; packet_t a = mkpkt(1U); packet_t o; size_t i; bool ok = true;
    pktq_init(&q);
    for (i = 0U; i < CHANNEL_CAP; i++) { (void)pktq_push(&q, &a, 0U); }
    for (i = 0U; i < 10U; i++) { if (!pktq_pop_due(&q, 0U, &o)) { ok = false; } }
    for (i = 0U; i < 10U; i++) { if (pktq_push(&q, &a, 0U) != STATUS_OK) { ok = false; } }
    CHECK(ok && q.count == CHANNEL_CAP && q.head == 10U);
}
TEST(test_x_pktq_null_arguments)
{
    pkt_queue_t q; packet_t a = mkpkt(1U); packet_t o;
    pktq_init(NULL); pktq_init(&q);
    CHECK(pktq_push(NULL, &a, 0U) == STATUS_ERR_NULL && pktq_push(&q, NULL, 0U) == STATUS_ERR_NULL);
    CHECK(!pktq_pop_due(NULL, 0U, &o) && !pktq_pop_due(&q, 0U, NULL));
}
TEST(test_x_ackq_fifo_and_due)
{
    ack_queue_t q; ack_t a; ack_t b; ack_t o;
    a.ack_seq = 1U; a.src = DST; a.dst = SRC; b = a; b.ack_seq = 2U;
    ackq_init(&q);
    CHECK(ackq_push(&q, &a, 3U) == STATUS_OK && ackq_push(&q, &b, 3U) == STATUS_OK);
    CHECK(!ackq_pop_due(&q, 2U, &o) && ackq_pop_due(&q, 3U, &o) && o.ack_seq == 1U && ackq_pop_due(&q, 3U, &o) && o.ack_seq == 2U);
}
TEST(test_x_ackq_full_and_null)
{
    ack_queue_t q; ack_t a; ack_t o; size_t i;
    a.ack_seq = 0U; a.src = DST; a.dst = SRC;
    ackq_init(NULL); ackq_init(&q);
    for (i = 0U; i < CHANNEL_CAP; i++) { (void)ackq_push(&q, &a, 0U); }
    CHECK(ackq_push(&q, &a, 0U) == STATUS_ERR_FULL && ackq_push(NULL, &a, 0U) == STATUS_ERR_NULL);
    CHECK(ackq_push(&q, NULL, 0U) == STATUS_ERR_NULL && !ackq_pop_due(NULL, 0U, &o) && !ackq_pop_due(&q, 0U, NULL));
}

/* ===================== E. Go-Back-N sender (24) ============================ */
TEST(test_x_sender_init_null)         { CHECK(sw_sender_init(NULL, 4U, 10U, SRC, DST) == STATUS_ERR_NULL); }
TEST(test_x_sender_init_window_zero)  { sw_sender_t s; CHECK(sw_sender_init(&s, 0U, 10U, SRC, DST) == STATUS_ERR_RANGE); }
TEST(test_x_sender_init_window_16)    { sw_sender_t s; CHECK(sw_sender_init(&s, 16U, 10U, SRC, DST) == STATUS_ERR_RANGE); }
TEST(test_x_sender_init_total_bounds) { sw_sender_t s; CHECK(sw_sender_init(&s, 4U, 0U, SRC, DST) == STATUS_ERR_RANGE && sw_sender_init(&s, 4U, SW_MAX_PACKETS + 1U, SRC, DST) == STATUS_ERR_RANGE && sw_sender_init(&s, 4U, SW_MAX_PACKETS, SRC, DST) == STATUS_OK); }
TEST(test_x_sender_init_bad_stations) { sw_sender_t s; CHECK(sw_sender_init(&s, 4U, 5U, 0U, DST) == STATUS_ERR_RANGE && sw_sender_init(&s, 4U, 5U, SRC, 0U) == STATUS_ERR_RANGE); }
TEST(test_x_sender_init_state)        { sw_sender_t s; CHECK(sw_sender_init(&s, 4U, 9U, SRC, DST) == STATUS_OK && s.base_abs == 0U && s.next_abs == 0U && s.window == 4U && s.total == 9U && sw_sender_outstanding(&s) == 0U); }
TEST(test_x_sender_null_queries)      { CHECK(sw_sender_outstanding(NULL) == 0U && !sw_sender_can_send(NULL) && !sw_sender_timed_out(NULL, 10U, 1U)); }
TEST(test_x_sender_next_packet_seq_and_status)
{
    sw_sender_t s; packet_t *p = NULL; const uint8_t pl[1] = {9U};
    CHECK(sw_sender_init(&s, 4U, 9U, SRC, DST) == STATUS_OK);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 7U, &p) == STATUS_OK && p != NULL);
    if (p != NULL) { CHECK(p->seq == 0U && p->status == PKT_STATUS_SENT && p->sent_tick == 7U && s.timer_start == 7U); }
}
TEST(test_x_sender_window_closes)
{
    sw_sender_t s; packet_t *p = NULL; const uint8_t pl[1] = {1U}; uint32_t i;
    CHECK(sw_sender_init(&s, 3U, 9U, SRC, DST) == STATUS_OK);
    for (i = 0U; i < 3U; i++) { CHECK(sw_sender_next_packet(&s, pl, 1U, 0U, &p) == STATUS_OK); }
    CHECK(!sw_sender_can_send(&s) && sw_sender_outstanding(&s) == 3U);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 0U, &p) == STATUS_ERR_FULL);
}
TEST(test_x_sender_exhausted_returns_empty)
{
    sw_sender_t s; packet_t *p = NULL; const uint8_t pl[1] = {1U};
    CHECK(sw_sender_init(&s, 5U, 2U, SRC, DST) == STATUS_OK);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 0U, &p) == STATUS_OK && sw_sender_next_packet(&s, pl, 1U, 0U, &p) == STATUS_OK);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 0U, &p) == STATUS_ERR_EMPTY && !sw_sender_can_send(&s));
}
TEST(test_x_sender_next_packet_null_args) { sw_sender_t s; packet_t *p = NULL; const uint8_t pl[1] = {1U}; CHECK(sw_sender_init(&s, 2U, 2U, SRC, DST) == STATUS_OK); CHECK(sw_sender_next_packet(NULL, pl, 1U, 0U, &p) == STATUS_ERR_NULL && sw_sender_next_packet(&s, pl, 1U, 0U, NULL) == STATUS_ERR_NULL); }
TEST(test_x_sender_next_packet_oversize_payload)
{
    sw_sender_t s; packet_t *p = NULL; uint8_t big[PAYLOAD_MAX + 1U];
    (void)memset(big, 1, sizeof(big));
    CHECK(sw_sender_init(&s, 2U, 2U, SRC, DST) == STATUS_OK);
    CHECK(sw_sender_next_packet(&s, big, sizeof(big), 0U, &p) == STATUS_ERR_RANGE && s.next_abs == 0U);
}
static void send_n(sw_sender_t *s, uint32_t n, uint32_t now)
{
    packet_t *p = NULL; const uint8_t pl[2] = {1U, 2U}; uint32_t i;
    for (i = 0U; i < n; i++) { (void)sw_sender_next_packet(s, pl, 2U, now, &p); }
}
TEST(test_x_sender_ack_slides_window)
{
    sw_sender_t s; uint32_t adv = 99U;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 4U, 0U);
    CHECK(sw_sender_process_ack(&s, 2U, 5U, &adv) == STATUS_OK && adv == 2U && s.base_abs == 2U && sw_sender_outstanding(&s) == 2U);
    CHECK(s.slots[0].status == PKT_STATUS_ACKED && s.slots[1].status == PKT_STATUS_ACKED && s.slots[2].status == PKT_STATUS_SENT);
}
TEST(test_x_sender_ack_cumulative_all)
{
    sw_sender_t s; uint32_t adv = 0U;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 4U, 0U);
    CHECK(sw_sender_process_ack(&s, 4U, 5U, &adv) == STATUS_OK && adv == 4U && sw_sender_outstanding(&s) == 0U);
}
TEST(test_x_sender_duplicate_ack_ignored)
{
    sw_sender_t s; uint32_t adv = 9U;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 4U, 0U);
    CHECK(sw_sender_process_ack(&s, 0U, 5U, &adv) == STATUS_OK && adv == 0U && s.base_abs == 0U);
}
TEST(test_x_sender_ack_beyond_window_ignored)
{
    sw_sender_t s; uint32_t adv = 9U;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 2U, 0U);
    CHECK(sw_sender_process_ack(&s, 5U, 5U, &adv) == STATUS_OK && adv == 0U && s.base_abs == 0U);
}
TEST(test_x_sender_ack_invalid_seq)
{
    sw_sender_t s; uint32_t adv = 9U;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK);
    CHECK(sw_sender_process_ack(&s, SEQ_MODULUS, 0U, &adv) == STATUS_ERR_RANGE && adv == 0U);
    CHECK(sw_sender_process_ack(NULL, 0U, 0U, &adv) == STATUS_ERR_NULL && sw_sender_process_ack(&s, 0U, 0U, NULL) == STATUS_ERR_NULL);
}
TEST(test_x_sender_ack_restarts_timer)
{
    sw_sender_t s; uint32_t adv = 0U;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 3U, 0U);
    CHECK(sw_sender_process_ack(&s, 1U, 9U, &adv) == STATUS_OK && s.timer_start == 9U);
}
TEST(test_x_sender_sequence_wraps_over_many_rounds)
{
    sw_sender_t s; uint32_t adv = 0U; uint32_t round; bool ok = true;
    CHECK(sw_sender_init(&s, 4U, 40U, SRC, DST) == STATUS_OK);
    for (round = 0U; round < 7U; round++) {
        send_n(&s, 4U, round);
        if ((sw_sender_process_ack(&s, (uint8_t)((s.base_abs + 4U) % SEQ_MODULUS), round, &adv) != STATUS_OK) || (adv != 4U)) { ok = false; }
    }
    CHECK(ok && s.base_abs == 28U && sw_sender_outstanding(&s) == 0U);
}
TEST(test_x_sender_timeout_threshold)
{
    sw_sender_t s;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 1U, 10U);
    CHECK(!sw_sender_timed_out(&s, 14U, 5U) && sw_sender_timed_out(&s, 15U, 5U) && sw_sender_timed_out(&s, 99U, 5U));
}
TEST(test_x_sender_no_timeout_when_idle_or_clock_behind)
{
    sw_sender_t s;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK);
    CHECK(!sw_sender_timed_out(&s, 100U, 1U));          /* nothing outstanding */
    send_n(&s, 1U, 50U);
    CHECK(!sw_sender_timed_out(&s, 10U, 1U));           /* now < timer_start */
}
TEST(test_x_sender_retransmit_marks_packet)
{
    sw_sender_t s; packet_t *p = NULL;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 3U, 0U);
    CHECK(sw_sender_mark_retransmit(&s, 1U, 3U, 8U, &p) == STATUS_OK && p != NULL);
    if (p != NULL) { CHECK(p->seq == 1U && p->retry_count == 1U && p->status == PKT_STATUS_RETRANSMITTED && p->sent_tick == 8U); }
}
TEST(test_x_sender_retransmit_limit)
{
    sw_sender_t s; packet_t *p = NULL;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 1U, 0U);
    CHECK(sw_sender_mark_retransmit(&s, 0U, 2U, 1U, &p) == STATUS_OK && sw_sender_mark_retransmit(&s, 0U, 2U, 2U, &p) == STATUS_OK);
    CHECK(sw_sender_mark_retransmit(&s, 0U, 2U, 3U, &p) == STATUS_ERR_MAX_RETRIES);
}
TEST(test_x_sender_retransmit_bad_args)
{
    sw_sender_t s; packet_t *p = NULL;
    CHECK(sw_sender_init(&s, 4U, 20U, SRC, DST) == STATUS_OK); send_n(&s, 2U, 0U);
    CHECK(sw_sender_mark_retransmit(&s, 2U, 3U, 0U, &p) == STATUS_ERR_RANGE);
    CHECK(sw_sender_mark_retransmit(NULL, 0U, 3U, 0U, &p) == STATUS_ERR_NULL && sw_sender_mark_retransmit(&s, 0U, 3U, 0U, NULL) == STATUS_ERR_NULL);
}

/* ===================== F. Go-Back-N receiver (10) ========================== */
TEST(test_x_receiver_init_bounds)     { sw_receiver_t r; CHECK(sw_receiver_init(NULL, 4U) == STATUS_ERR_NULL && sw_receiver_init(&r, 0U) == STATUS_ERR_RANGE && sw_receiver_init(&r, 16U) == STATUS_ERR_RANGE && sw_receiver_init(&r, 15U) == STATUS_OK && r.expected_seq == 0U && r.delivered == 0U); }
TEST(test_x_receiver_accepts_in_order)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_OUT_OF_ORDER; packet_t p = mkpkt(0U);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK && res == RX_ACCEPTED && a.ack_seq == 1U && r.delivered == 1U && r.expected_seq == 1U);
}
TEST(test_x_receiver_ack_addresses_swapped)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_ACCEPTED; packet_t p = mkpkt(0U);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK && sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK);
    CHECK(a.src == DST && a.dst == SRC);
}
TEST(test_x_receiver_out_of_order_discarded)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_ACCEPTED; packet_t p = mkpkt(2U);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK && res == RX_OUT_OF_ORDER && a.ack_seq == 0U && r.delivered == 0U);
}
TEST(test_x_receiver_duplicate_reacks)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_ACCEPTED; packet_t p0 = mkpkt(0U); packet_t p1 = mkpkt(1U);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    CHECK(sw_receiver_on_packet(&r, &p0, &a, &res) == STATUS_OK && sw_receiver_on_packet(&r, &p1, &a, &res) == STATUS_OK);
    CHECK(sw_receiver_on_packet(&r, &p0, &a, &res) == STATUS_OK && res == RX_DUPLICATE && a.ack_seq == 2U && r.delivered == 2U);
}
TEST(test_x_receiver_corrupt_packet_rejected)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_ACCEPTED; packet_t p = mkpkt(0U);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    p.payload[0] ^= 0x10U;
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_ERR_FORMAT && r.delivered == 0U && r.expected_seq == 0U);
}
TEST(test_x_receiver_bad_sequence_range) { sw_receiver_t r; ack_t a; rx_result_t res = RX_ACCEPTED; packet_t p = mkpkt(0U); CHECK(sw_receiver_init(&r, 4U) == STATUS_OK); p.seq = SEQ_MODULUS; CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_ERR_RANGE); }
TEST(test_x_receiver_null_arguments)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_ACCEPTED; packet_t p = mkpkt(0U);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    CHECK(sw_receiver_on_packet(NULL, &p, &a, &res) == STATUS_ERR_NULL && sw_receiver_on_packet(&r, NULL, &a, &res) == STATUS_ERR_NULL);
    CHECK(sw_receiver_on_packet(&r, &p, NULL, &res) == STATUS_ERR_NULL && sw_receiver_on_packet(&r, &p, &a, NULL) == STATUS_ERR_NULL);
}
TEST(test_x_receiver_wraps_expected_seq)
{
    sw_receiver_t r; ack_t a; rx_result_t res = RX_OUT_OF_ORDER; uint32_t i; bool ok = true;
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    for (i = 0U; i < 20U; i++) { packet_t p = mkpkt((uint8_t)(i % SEQ_MODULUS)); if ((sw_receiver_on_packet(&r, &p, &a, &res) != STATUS_OK) || (res != RX_ACCEPTED)) { ok = false; } }
    CHECK(ok && r.delivered == 20U && r.expected_seq == 4U && a.ack_seq == 4U);
}

/* ===================== G. configuration + simulation (30) ================== */
TEST(test_x_cfg_default_values)       { sw_config_t c; CHECK(sw_config_default(&c) == STATUS_OK && c.window_size == 4U && c.packet_count == 12U && c.timeout_ticks == 5U && c.max_retries == 6U && sw_config_validate(&c) == STATUS_OK); }
TEST(test_x_cfg_timeout_bounds)       { sw_config_t c = scfg(4U, 5U); c.timeout_ticks = 100U; CHECK(sw_config_validate(&c) == STATUS_OK); c.timeout_ticks = 101U; CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE); }
TEST(test_x_cfg_retries_bounds)       { sw_config_t c = scfg(4U, 5U); c.max_retries = 20U; CHECK(sw_config_validate(&c) == STATUS_OK); c.max_retries = 21U; CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE); }
TEST(test_x_cfg_loss_every_bounds)    { sw_config_t c = scfg(4U, 5U); c.data_loss_every = 1000U; c.ack_loss_every = 1000U; CHECK(sw_config_validate(&c) == STATUS_OK); c.ack_loss_every = 1001U; CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE); c.ack_loss_every = 0U; c.data_loss_every = 1001U; CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE); }
TEST(test_x_cfg_loss_percent_bounds)  { sw_config_t c = scfg(4U, 5U); c.data_loss_percent = 100U; c.ack_loss_percent = 100U; CHECK(sw_config_validate(&c) == STATUS_OK); c.ack_loss_percent = 101U; CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE); }
TEST(test_x_sim_null_arguments)       { sw_config_t c = scfg(4U, 5U); sw_stats_t st; CHECK(sw_simulate(NULL, SRC, DST, NULL, &st) == STATUS_ERR_NULL && sw_simulate(&c, SRC, DST, NULL, NULL) == STATUS_ERR_NULL); }
TEST(test_x_sim_invalid_endpoint)     { sw_config_t c = scfg(4U, 5U); sw_stats_t st; CHECK(sw_simulate(&c, 0U, DST, NULL, &st) == STATUS_ERR_RANGE && st.delivered == 0U); }
TEST(test_x_sim_invalid_config_zeroes_stats) { sw_config_t c = scfg(4U, 5U); sw_stats_t st; (void)memset(&st, 0xAB, sizeof(st)); c.timeout_ticks = 0U; CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_RANGE && st.data_tx == 0U && st.ticks == 0U); }
static void lossless(uint8_t w, uint32_t n)
{
    sw_config_t c = scfg(w, n); sw_stats_t st;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == n && st.data_tx == n && st.retransmissions == 0U && st.timeouts == 0U && st.data_lost == 0U);
    CHECK(st.data_received == n && st.acks_sent == n && st.acks_received <= n && st.ticks > 0U);
}
TEST(test_x_sim_lossless_window_1)    { lossless(1U, 25U); }
TEST(test_x_sim_lossless_window_2)    { lossless(2U, 25U); }
TEST(test_x_sim_lossless_window_7)    { lossless(7U, 40U); }
TEST(test_x_sim_lossless_window_15)   { lossless(15U, 100U); }
TEST(test_x_sim_single_packet)        { lossless(4U, 1U); }
TEST(test_x_sim_max_packets)          { lossless(15U, SW_MAX_PACKETS); }
TEST(test_x_sim_bigger_window_is_faster)
{
    sw_config_t a = scfg(1U, 30U); sw_config_t b = scfg(8U, 30U); sw_stats_t sa; sw_stats_t sb;
    CHECK(sw_simulate(&a, SRC, DST, NULL, &sa) == STATUS_OK && sw_simulate(&b, SRC, DST, NULL, &sb) == STATUS_OK);
    CHECK(sb.ticks < sa.ticks);
}
static void lossy_ok(uint32_t data_every, uint32_t ack_every)
{
    sw_config_t c = scfg(4U, 30U); sw_stats_t st;
    c.data_loss_every = data_every; c.ack_loss_every = ack_every; c.max_retries = 20U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK && st.delivered == 30U);
    CHECK(st.data_tx == (30U + st.retransmissions));
}
TEST(test_x_sim_data_loss_every_2_starves_and_aborts)
{
    sw_config_t c = scfg(4U, 30U); sw_stats_t st; c.data_loss_every = 2U; c.max_retries = 20U;
    /* a strictly periodic pattern can starve one packet forever: the engine must stop */
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_MAX_RETRIES && st.delivered < 30U && st.ticks < SW_MAX_TICKS);
}
TEST(test_x_sim_data_loss_every_3)    { lossy_ok(3U, 0U); }
TEST(test_x_sim_data_loss_every_7)    { lossy_ok(7U, 0U); }
TEST(test_x_sim_ack_loss_every_2)     { lossy_ok(0U, 2U); }
TEST(test_x_sim_ack_loss_every_5)     { lossy_ok(0U, 5U); }
TEST(test_x_sim_both_losses)          { lossy_ok(5U, 7U); }
TEST(test_x_sim_data_loss_causes_timeouts_and_retx)
{
    sw_config_t c = scfg(4U, 20U); sw_stats_t st; c.data_loss_every = 3U; c.max_retries = 20U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK && st.timeouts > 0U && st.retransmissions > 0U && st.data_lost > 0U);
}
TEST(test_x_sim_go_back_n_discards_out_of_order)
{
    sw_config_t c = scfg(5U, 20U); sw_stats_t st; c.data_loss_every = 4U; c.max_retries = 20U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK && st.out_of_order > 0U && st.delivered == 20U);
}
TEST(test_x_sim_lost_acks_create_duplicates)
{
    sw_config_t c = scfg(1U, 10U); sw_stats_t st; c.ack_loss_every = 2U; c.max_retries = 20U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK && st.duplicates > 0U && st.delivered == 10U);
}
TEST(test_x_sim_total_data_loss_hits_retry_limit)
{
    sw_config_t c = scfg(3U, 6U); sw_stats_t st; c.data_loss_every = 1U; c.max_retries = 3U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_MAX_RETRIES && st.delivered == 0U && st.timeouts == 4U);
}
TEST(test_x_sim_total_ack_loss_hits_retry_limit)
{
    sw_config_t c = scfg(3U, 6U); sw_stats_t st; c.ack_loss_every = 1U; c.max_retries = 2U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_MAX_RETRIES);
}
TEST(test_x_sim_random_loss_recovers)
{
    uint32_t seed; bool ok = true;
    for (seed = 1U; seed <= 3U; seed++) {
        sw_config_t c = scfg(5U, 40U); sw_stats_t st;
        c.data_loss_percent = 10U; c.ack_loss_percent = 10U; c.max_retries = 20U; c.seed = seed;
        if ((sw_simulate(&c, SRC, DST, NULL, &st) != STATUS_OK) || (st.delivered != 40U)) { ok = false; }
    }
    CHECK(ok);
}
TEST(test_x_sim_same_seed_same_result)
{
    sw_config_t c = scfg(5U, 40U); sw_stats_t a; sw_stats_t b;
    c.data_loss_percent = 20U; c.ack_loss_percent = 10U; c.max_retries = 20U; c.seed = 777U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &a) == STATUS_OK && sw_simulate(&c, SRC, DST, NULL, &b) == STATUS_OK);
    CHECK(a.data_tx == b.data_tx && a.data_lost == b.data_lost && a.acks_lost == b.acks_lost && a.ticks == b.ticks && a.timeouts == b.timeouts);
}
TEST(test_x_sim_stats_invariants_under_loss)
{
    sw_config_t c = scfg(4U, 30U); sw_stats_t st; c.data_loss_every = 7U; c.ack_loss_every = 11U; c.max_retries = 20U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.data_tx >= (st.data_lost + st.data_received) && st.acks_sent >= (st.acks_lost + st.acks_received));
    CHECK(((st.delivered * 100U) / st.data_tx) <= 100U && st.dup_acks <= st.acks_received);
}
TEST(test_x_sim_print_stats_content)
{
    sw_config_t c = scfg(4U, 10U); sw_stats_t st; FILE *f = fopen(EXT_FILE, "w+"); char b[2048]; size_t n;
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    sw_print_stats(f, &st); rewind(f); n = fread(b, 1U, sizeof(b) - 1U, f); b[n] = '\0';
    CHECK(strstr(b, "Packets requested      : 10") != NULL && strstr(b, "Packets delivered (ok) : 10") != NULL && strstr(b, "Efficiency (delivered/tx): 100%") != NULL);
    (void)fclose(f); (void)remove(EXT_FILE);
}

/* ===================== H. storage + status strings (26) ==================== */
static void clean_ext(void) { (void)remove(EXT_FILE); (void)remove(EXT_FILE ".tmp"); }
static status_t load_text(bst_t *t, const char *text) { write_file(EXT_FILE, text); return storage_load(t, EXT_FILE); }
TEST(test_x_storage_save_writes_header_first)
{
    bst_t t; FILE *f; char line[64]; build(&t, k_shape, 7U);
    CHECK(storage_save(&t, EXT_FILE) == STATUS_OK);
    f = fopen(EXT_FILE, "r"); CHECK(f != NULL);
    if (f != NULL) { CHECK(fgets(line, (int)sizeof(line), f) != NULL && strcmp(line, "STATIONS_V2\n") == 0); (void)fclose(f); }
    bst_destroy(&t); clean_ext();
}
TEST(test_x_storage_save_uses_preorder)
{
    bst_t t; FILE *f; char line[64]; build(&t, k_shape, 7U);
    CHECK(storage_save(&t, EXT_FILE) == STATUS_OK);
    f = fopen(EXT_FILE, "r"); CHECK(f != NULL);
    if (f != NULL) { CHECK(fgets(line, (int)sizeof(line), f) != NULL && fgets(line, (int)sizeof(line), f) != NULL && strncmp(line, "50|", 3U) == 0); (void)fclose(f); }
    bst_destroy(&t); clean_ext();
}
TEST(test_x_storage_roundtrip_preserves_tree)
{
    bst_t a; bst_t b; const station_t *f; const station_id_t want[7] = {20U, 30U, 40U, 50U, 60U, 70U, 80U};
    build(&a, k_shape, 7U); bst_init(&b);
    CHECK(storage_save(&a, EXT_FILE) == STATUS_OK && storage_load(&b, EXT_FILE) == STATUS_OK);
    f = bst_search(&b, 40U);
    CHECK(order_is(&b, false, want, 7U) && order_is(&b, true, k_pre, 7U) && f != NULL && strcmp(f->name, "Stn") == 0 && f->distance_km == 40U);
    bst_destroy(&a); bst_destroy(&b); clean_ext();
}
TEST(test_x_storage_save_empty_tree)  { bst_t t; bst_t u; bst_init(&t); bst_init(&u); CHECK(storage_save(&t, EXT_FILE) == STATUS_OK && storage_load(&u, EXT_FILE) == STATUS_OK && u.count == 0U); clean_ext(); }
TEST(test_x_storage_save_null_args)   { bst_t t; bst_init(&t); CHECK(storage_save(NULL, EXT_FILE) == STATUS_ERR_NULL && storage_save(&t, NULL) == STATUS_ERR_NULL); }
TEST(test_x_storage_save_bad_path)
{
    bst_t t; char longp[300]; bst_init(&t);
    (void)memset(longp, 'a', sizeof(longp)); longp[299] = '\0';
    CHECK(storage_save(&t, "") == STATUS_ERR_RANGE && storage_save(&t, longp) == STATUS_ERR_RANGE);
    CHECK(storage_save(&t, "no_such_dir_xyz/s.txt") == STATUS_ERR_IO);
}
TEST(test_x_storage_save_leaves_no_tmp_file)
{
    bst_t t; FILE *f; build(&t, k_shape, 3U);
    CHECK(storage_save(&t, EXT_FILE) == STATUS_OK);
    f = fopen(EXT_FILE ".tmp", "r"); CHECK(f == NULL);
    if (f != NULL) { (void)fclose(f); }
    bst_destroy(&t); clean_ext();
}
TEST(test_x_storage_save_overwrites_old_file)
{
    bst_t t; bst_t u; build(&t, k_shape, 7U); bst_init(&u);
    write_file(EXT_FILE, "garbage that must disappear\n");
    CHECK(storage_save(&t, EXT_FILE) == STATUS_OK && storage_load(&u, EXT_FILE) == STATUS_OK && u.count == 7U);
    bst_destroy(&t); bst_destroy(&u); clean_ext();
}
TEST(test_x_storage_load_missing_file){ bst_t t; bst_init(&t); CHECK(storage_load(&t, "no_such_file_xyz.txt") == STATUS_ERR_IO); }
TEST(test_x_storage_load_null_args)   { bst_t t; bst_init(&t); CHECK(storage_load(NULL, EXT_FILE) == STATUS_ERR_NULL && storage_load(&t, NULL) == STATUS_ERR_NULL); }
TEST(test_x_storage_load_header_only) { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n") == STATUS_OK && t.count == 0U); clean_ext(); }
TEST(test_x_storage_load_comments_and_blanks)
{
    bst_t t; bst_init(&t);
    CHECK(load_text(&t, "# note\n\nSTATIONS_V2\n# more\n\n7|Seven|1|2|3|Core\n\n") == STATUS_OK && t.count == 1U);
    bst_destroy(&t); clean_ext();
}
TEST(test_x_storage_load_crlf_lines)  { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\r\n7|Seven|1|2|3|Core\r\n") == STATUS_OK && t.count == 1U); bst_destroy(&t); clean_ext(); }
TEST(test_x_storage_load_no_final_newline) { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n7|Seven|1|2|3|Core") == STATUS_OK && t.count == 1U); bst_destroy(&t); clean_ext(); }
TEST(test_x_storage_load_missing_header) { bst_t t; bst_init(&t); CHECK(load_text(&t, "7|Seven|1|2|3|Core\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_old_v1_header)  { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V1\n7|Seven|1|2\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_empty_file)     { bst_t t; bst_init(&t); CHECK(load_text(&t, "") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_too_few_fields) { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n7|Seven|1|2|3\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_too_many_fields){ bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n7|Seven|1|2|3|Core|x\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_non_numeric)    { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\nabc|Seven|1|2|3|Core\n") == STATUS_ERR_FORMAT && load_text(&t, "STATIONS_V2\n7|Seven|x|2|3|Core\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_out_of_range_numbers) { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n0|Seven|1|2|3|Core\n") == STATUS_ERR_FORMAT && load_text(&t, "STATIONS_V2\n7|Seven|1|2|0|Core\n") == STATUS_ERR_FORMAT && load_text(&t, "STATIONS_V2\n7|Seven|1|2|100|Core\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_invalid_name)   { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n7|Sev;en|1|2|3|Core\n") == STATUS_ERR_FORMAT); clean_ext(); }
TEST(test_x_storage_load_duplicate_ids)  { bst_t t; bst_init(&t); CHECK(load_text(&t, "STATIONS_V2\n7|A|1|2|3|Core\n7|B|1|2|3|Core\n") == STATUS_ERR_DUPLICATE && t.count == 0U); clean_ext(); }
TEST(test_x_storage_load_overlong_line)
{
    bst_t t; char big[300]; char text[400]; bst_init(&t);
    (void)memset(big, 'a', sizeof(big)); big[299] = '\0';
    (void)snprintf(text, sizeof(text), "STATIONS_V2\n7|%s|1|2|3|Core\n", big);
    CHECK(load_text(&t, text) == STATUS_ERR_FORMAT); clean_ext();
}
TEST(test_x_storage_failed_load_keeps_tree)
{
    bst_t t; build(&t, k_shape, 7U);
    CHECK(load_text(&t, "STATIONS_V2\n7|A|1|2|3|Core\nbroken line\n") == STATUS_ERR_FORMAT && t.count == 7U && order_is(&t, true, k_pre, 7U));
    bst_destroy(&t); clean_ext();
}
TEST(test_x_storage_successful_load_replaces_tree)
{
    bst_t t; build(&t, k_shape, 7U);
    CHECK(load_text(&t, "STATIONS_V2\n9|Nine|1|2|3|Core\n") == STATUS_OK && t.count == 1U && bst_search(&t, 9U) != NULL && bst_search(&t, 50U) == NULL);
    bst_destroy(&t); clean_ext();
}
TEST(test_x_status_strings_distinct_and_nonnull)
{
    int i; int j; bool ok = true;
    for (i = 0; i <= (int)STATUS_ERR_MAX_RETRIES; i++) {
        const char *a = status_to_string((status_t)i);
        if ((a == NULL) || (a[0] == '\0')) { ok = false; continue; }
        for (j = 0; j < i; j++) { if (strcmp(a, status_to_string((status_t)j)) == 0) { ok = false; } }
    }
    CHECK(ok);
}
TEST(test_x_status_unknown_value)     { CHECK(strcmp(status_to_string((status_t)99), "unknown error") == 0 && strcmp(status_to_string(STATUS_OK), "success") == 0); }
TEST(test_x_station_print_is_null_safe) { station_t s = mk(5U); station_print(&s); station_print(NULL); CHECK(station_validate(&s) == STATUS_OK); }

int main(void)
{
    RUN_TEST(test_x_station_id_min_ok);
    RUN_TEST(test_x_station_id_max_ok);
    RUN_TEST(test_x_station_id_zero_bad);
    RUN_TEST(test_x_station_id_over_max_bad);
    RUN_TEST(test_x_station_id_uint_max_bad);
    RUN_TEST(test_x_name_one_char_ok);
    RUN_TEST(test_x_name_31_chars_ok);
    RUN_TEST(test_x_name_32_chars_bad);
    RUN_TEST(test_x_type_15_chars_ok);
    RUN_TEST(test_x_type_16_chars_bad);
    RUN_TEST(test_x_text_digits_ok);
    RUN_TEST(test_x_text_punctuation_allowed);
    RUN_TEST(test_x_text_inner_double_space);
    RUN_TEST(test_x_text_only_space_bad);
    RUN_TEST(test_x_text_tab_bad);
    RUN_TEST(test_x_text_semicolon_bad);
    RUN_TEST(test_x_text_quote_bad);
    RUN_TEST(test_x_text_slash_bad);
    RUN_TEST(test_x_text_high_byte_bad);
    RUN_TEST(test_x_text_trailing_space_bad);
    RUN_TEST(test_x_numbers_all_max_ok);
    RUN_TEST(test_x_numbers_platform_zero_bad);
    RUN_TEST(test_x_parse_zero);
    RUN_TEST(test_x_parse_leading_zeros);
    RUN_TEST(test_x_parse_surrounding_blanks);
    RUN_TEST(test_x_parse_inner_space_bad);
    RUN_TEST(test_x_parse_plus_sign_bad);
    RUN_TEST(test_x_parse_minus_sign_bad);
    RUN_TEST(test_x_parse_hex_bad);
    RUN_TEST(test_x_parse_exponent_bad);
    RUN_TEST(test_x_parse_decimal_bad);
    RUN_TEST(test_x_parse_empty_bad);
    RUN_TEST(test_x_parse_blank_only_bad);
    RUN_TEST(test_x_parse_below_min);
    RUN_TEST(test_x_parse_above_max);
    RUN_TEST(test_x_parse_exact_bounds);
    RUN_TEST(test_x_parse_uint32_max);
    RUN_TEST(test_x_parse_uint32_overflow);
    RUN_TEST(test_x_parse_huge_digit_string);
    RUN_TEST(test_x_parse_failure_keeps_value);
    RUN_TEST(test_x_prompt_third_attempt_ok);
    RUN_TEST(test_x_prompt_three_failures_range);
    RUN_TEST(test_x_prompt_eof_is_io);
    RUN_TEST(test_x_prompt_null_arguments);
    RUN_TEST(test_x_read_line_capacity_limits);
    RUN_TEST(test_x_bst_init_null_safe);
    RUN_TEST(test_x_bst_init_clears);
    RUN_TEST(test_x_bst_insert_null_args);
    RUN_TEST(test_x_bst_insert_invalid_station);
    RUN_TEST(test_x_bst_inorder_sorted);
    RUN_TEST(test_x_bst_preorder_shape);
    RUN_TEST(test_x_bst_count_after_inserts);
    RUN_TEST(test_x_bst_duplicate_keeps_count);
    RUN_TEST(test_x_bst_search_hit_and_miss);
    RUN_TEST(test_x_bst_search_null_tree);
    RUN_TEST(test_x_bst_search_empty_tree);
    RUN_TEST(test_x_bst_update_changes_fields);
    RUN_TEST(test_x_bst_update_missing_id);
    RUN_TEST(test_x_bst_update_invalid_keeps_old);
    RUN_TEST(test_x_bst_update_null_tree);
    RUN_TEST(test_x_bst_delete_leaf);
    RUN_TEST(test_x_bst_delete_one_child_right);
    RUN_TEST(test_x_bst_delete_one_child_left);
    RUN_TEST(test_x_bst_delete_two_children_uses_successor);
    RUN_TEST(test_x_bst_delete_missing);
    RUN_TEST(test_x_bst_delete_all_then_empty);
    RUN_TEST(test_x_bst_stats_min_max);
    RUN_TEST(test_x_bst_stats_empty_and_null);
    RUN_TEST(test_x_bst_traversal_null_visitor);
    RUN_TEST(test_x_bst_destroy_resets);
    RUN_TEST(test_x_bst_descending_insert_chain);
    RUN_TEST(test_x_seq_distance_same);
    RUN_TEST(test_x_seq_distance_forward);
    RUN_TEST(test_x_seq_distance_wrap);
    RUN_TEST(test_x_seq_distance_backward);
    RUN_TEST(test_x_seq_next_wraps);
    RUN_TEST(test_x_seq_next_full_cycle);
    RUN_TEST(test_x_packet_init_fields);
    RUN_TEST(test_x_packet_init_empty_payload);
    RUN_TEST(test_x_packet_init_max_payload);
    RUN_TEST(test_x_packet_init_bad_endpoint);
    RUN_TEST(test_x_packet_verify_ok);
    RUN_TEST(test_x_packet_verify_null);
    RUN_TEST(test_x_packet_detects_payload_flip);
    RUN_TEST(test_x_packet_detects_seq_change);
    RUN_TEST(test_x_packet_detects_src_change);
    RUN_TEST(test_x_packet_detects_dst_change);
    RUN_TEST(test_x_packet_detects_len_change);
    RUN_TEST(test_x_packet_rejects_bad_len);
    RUN_TEST(test_x_packet_checksum_deterministic);
    RUN_TEST(test_x_pktq_fifo_order);
    RUN_TEST(test_x_pktq_respects_due_tick);
    RUN_TEST(test_x_pktq_full_at_capacity);
    RUN_TEST(test_x_pktq_wraparound);
    RUN_TEST(test_x_pktq_null_arguments);
    RUN_TEST(test_x_ackq_fifo_and_due);
    RUN_TEST(test_x_ackq_full_and_null);
    RUN_TEST(test_x_sender_init_null);
    RUN_TEST(test_x_sender_init_window_zero);
    RUN_TEST(test_x_sender_init_window_16);
    RUN_TEST(test_x_sender_init_total_bounds);
    RUN_TEST(test_x_sender_init_bad_stations);
    RUN_TEST(test_x_sender_init_state);
    RUN_TEST(test_x_sender_null_queries);
    RUN_TEST(test_x_sender_next_packet_seq_and_status);
    RUN_TEST(test_x_sender_window_closes);
    RUN_TEST(test_x_sender_exhausted_returns_empty);
    RUN_TEST(test_x_sender_next_packet_null_args);
    RUN_TEST(test_x_sender_next_packet_oversize_payload);
    RUN_TEST(test_x_sender_ack_slides_window);
    RUN_TEST(test_x_sender_ack_cumulative_all);
    RUN_TEST(test_x_sender_duplicate_ack_ignored);
    RUN_TEST(test_x_sender_ack_beyond_window_ignored);
    RUN_TEST(test_x_sender_ack_invalid_seq);
    RUN_TEST(test_x_sender_ack_restarts_timer);
    RUN_TEST(test_x_sender_sequence_wraps_over_many_rounds);
    RUN_TEST(test_x_sender_timeout_threshold);
    RUN_TEST(test_x_sender_no_timeout_when_idle_or_clock_behind);
    RUN_TEST(test_x_sender_retransmit_marks_packet);
    RUN_TEST(test_x_sender_retransmit_limit);
    RUN_TEST(test_x_sender_retransmit_bad_args);
    RUN_TEST(test_x_receiver_init_bounds);
    RUN_TEST(test_x_receiver_accepts_in_order);
    RUN_TEST(test_x_receiver_ack_addresses_swapped);
    RUN_TEST(test_x_receiver_out_of_order_discarded);
    RUN_TEST(test_x_receiver_duplicate_reacks);
    RUN_TEST(test_x_receiver_corrupt_packet_rejected);
    RUN_TEST(test_x_receiver_bad_sequence_range);
    RUN_TEST(test_x_receiver_null_arguments);
    RUN_TEST(test_x_receiver_wraps_expected_seq);
    RUN_TEST(test_x_cfg_default_values);
    RUN_TEST(test_x_cfg_timeout_bounds);
    RUN_TEST(test_x_cfg_retries_bounds);
    RUN_TEST(test_x_cfg_loss_every_bounds);
    RUN_TEST(test_x_cfg_loss_percent_bounds);
    RUN_TEST(test_x_sim_null_arguments);
    RUN_TEST(test_x_sim_invalid_endpoint);
    RUN_TEST(test_x_sim_invalid_config_zeroes_stats);
    RUN_TEST(test_x_sim_lossless_window_1);
    RUN_TEST(test_x_sim_lossless_window_2);
    RUN_TEST(test_x_sim_lossless_window_7);
    RUN_TEST(test_x_sim_lossless_window_15);
    RUN_TEST(test_x_sim_single_packet);
    RUN_TEST(test_x_sim_max_packets);
    RUN_TEST(test_x_sim_bigger_window_is_faster);
    RUN_TEST(test_x_sim_data_loss_every_2_starves_and_aborts);
    RUN_TEST(test_x_sim_data_loss_every_3);
    RUN_TEST(test_x_sim_data_loss_every_7);
    RUN_TEST(test_x_sim_ack_loss_every_2);
    RUN_TEST(test_x_sim_ack_loss_every_5);
    RUN_TEST(test_x_sim_both_losses);
    RUN_TEST(test_x_sim_data_loss_causes_timeouts_and_retx);
    RUN_TEST(test_x_sim_go_back_n_discards_out_of_order);
    RUN_TEST(test_x_sim_lost_acks_create_duplicates);
    RUN_TEST(test_x_sim_total_data_loss_hits_retry_limit);
    RUN_TEST(test_x_sim_total_ack_loss_hits_retry_limit);
    RUN_TEST(test_x_sim_random_loss_recovers);
    RUN_TEST(test_x_sim_same_seed_same_result);
    RUN_TEST(test_x_sim_stats_invariants_under_loss);
    RUN_TEST(test_x_sim_print_stats_content);
    RUN_TEST(test_x_storage_save_writes_header_first);
    RUN_TEST(test_x_storage_save_uses_preorder);
    RUN_TEST(test_x_storage_roundtrip_preserves_tree);
    RUN_TEST(test_x_storage_save_empty_tree);
    RUN_TEST(test_x_storage_save_null_args);
    RUN_TEST(test_x_storage_save_bad_path);
    RUN_TEST(test_x_storage_save_leaves_no_tmp_file);
    RUN_TEST(test_x_storage_save_overwrites_old_file);
    RUN_TEST(test_x_storage_load_missing_file);
    RUN_TEST(test_x_storage_load_null_args);
    RUN_TEST(test_x_storage_load_header_only);
    RUN_TEST(test_x_storage_load_comments_and_blanks);
    RUN_TEST(test_x_storage_load_crlf_lines);
    RUN_TEST(test_x_storage_load_no_final_newline);
    RUN_TEST(test_x_storage_load_missing_header);
    RUN_TEST(test_x_storage_load_old_v1_header);
    RUN_TEST(test_x_storage_load_empty_file);
    RUN_TEST(test_x_storage_load_too_few_fields);
    RUN_TEST(test_x_storage_load_too_many_fields);
    RUN_TEST(test_x_storage_load_non_numeric);
    RUN_TEST(test_x_storage_load_out_of_range_numbers);
    RUN_TEST(test_x_storage_load_invalid_name);
    RUN_TEST(test_x_storage_load_duplicate_ids);
    RUN_TEST(test_x_storage_load_overlong_line);
    RUN_TEST(test_x_storage_failed_load_keeps_tree);
    RUN_TEST(test_x_storage_successful_load_replaces_tree);
    RUN_TEST(test_x_status_strings_distinct_and_nonnull);
    RUN_TEST(test_x_status_unknown_value);
    RUN_TEST(test_x_station_print_is_null_safe);
    return TEST_SUMMARY();
}
