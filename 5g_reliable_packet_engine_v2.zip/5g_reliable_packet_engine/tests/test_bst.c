/* test_bst.c - BST unit tests. */
#include <stdlib.h>
#include <string.h>
#include "test_framework.h"
#include "bst.h"

static station_t mk(station_id_t id)
{
    station_t s;
    (void)station_init(&s, id, "Stn", id % 1000U, 100U, 1U, "gNodeB");
    return s;
}

typedef struct { station_id_t ids[BST_MAX_STATIONS]; size_t n; } collect_t;

static void collect(const station_t *s, void *ctx)
{
    collect_t *c = (collect_t *)ctx;
    if (c->n < BST_MAX_STATIONS) { c->ids[c->n] = s->id; c->n++; }
}

static void fill(bst_t *t, const station_id_t *ids, size_t n)
{
    size_t i;
    for (i = 0U; i < n; i++) {
        station_t s = mk(ids[i]);
        (void)bst_insert(t, &s);
    }
}

/* shape used by delete tests:        50
 *                                30       70
 *                              20  40   60  80      */
static const station_id_t SHAPE[] = {50U, 30U, 70U, 20U, 40U, 60U, 80U};

static void test_insert_empty(void)
{
    bst_t t; station_t s = mk(10U);
    bst_init(&t);
    CHECK(bst_insert(&t, &s) == STATUS_OK);
    CHECK(t.count == 1U);
    CHECK(t.root != NULL);
    bst_destroy(&t);
    CHECK(t.root == NULL && t.count == 0U);
}

static void test_insert_multiple_and_inorder_sorted(void)
{
    bst_t t; collect_t c; size_t i;
    const station_id_t in[] = {50U, 20U, 80U, 10U, 30U, 70U, 90U, 60U};
    bst_init(&t); c.n = 0U;
    fill(&t, in, 8U);
    CHECK(t.count == 8U);
    CHECK(bst_inorder(&t, collect, &c) == STATUS_OK);
    CHECK(c.n == 8U);
    for (i = 1U; i < c.n; i++) { CHECK(c.ids[i - 1U] < c.ids[i]); }
    bst_destroy(&t);
}

static void test_duplicate_rejected(void)
{
    bst_t t; station_t s = mk(5U);
    bst_init(&t);
    CHECK(bst_insert(&t, &s) == STATUS_OK);
    CHECK(bst_insert(&t, &s) == STATUS_ERR_DUPLICATE);
    CHECK(t.count == 1U);
    bst_destroy(&t);
}

static void test_search(void)
{
    bst_t t; const station_t *f;
    bst_init(&t);
    CHECK(bst_search(&t, 50U) == NULL);          /* empty tree */
    fill(&t, SHAPE, 7U);
    f = bst_search(&t, 60U);
    CHECK(f != NULL && f->id == 60U);
    CHECK(bst_search(&t, 61U) == NULL);
    CHECK(bst_search(NULL, 1U) == NULL);
    bst_destroy(&t);
}

static void test_update(void)
{
    bst_t t; const station_t *f;
    bst_init(&t);
    fill(&t, SHAPE, 7U);
    CHECK(bst_update(&t, 40U, "New Name", 777U, 100U, 1U, "Relay") == STATUS_OK);
    f = bst_search(&t, 40U);
    CHECK(f != NULL && strcmp(f->name, "New Name") == 0 && f->distance_km == 777U);
    CHECK(strcmp(f->type, "Relay") == 0);
    CHECK(f->fare == 100U && f->platform == 1U);
    /* fare and platform are updated together with the other details */
    CHECK(bst_update(&t, 40U, "New Name", 777U, 250U, 9U, "Relay") == STATUS_OK);
    f = bst_search(&t, 40U);
    CHECK(f != NULL && f->fare == 250U && f->platform == 9U);
    CHECK(bst_update(&t, 40U, "New Name", 777U, STATION_FARE_MAX + 1U, 9U, "Relay") == STATUS_ERR_RANGE);
    CHECK(bst_update(&t, 40U, "New Name", 777U, 250U, 0U, "Relay") == STATUS_ERR_RANGE);
    f = bst_search(&t, 40U);
    CHECK(f != NULL && f->fare == 250U && f->platform == 9U);      /* untouched on error */
    CHECK(bst_update(&t, 999U, "X", 1U, 100U, 1U, "Y") == STATUS_ERR_NOT_FOUND);
    /* invalid update must leave the record untouched */
    CHECK(bst_update(&t, 40U, "Bad|Name", 1U, 100U, 1U, "Y") == STATUS_ERR_FORMAT);
    CHECK(bst_update(&t, 40U, "OK", 999999U, 100U, 1U, "Y") == STATUS_ERR_RANGE);
    f = bst_search(&t, 40U);
    CHECK(f != NULL && strcmp(f->name, "New Name") == 0);
    bst_destroy(&t);
}

static void test_delete_leaf(void)
{
    bst_t t; collect_t c;
    bst_init(&t); c.n = 0U; fill(&t, SHAPE, 7U);
    CHECK(bst_delete(&t, 20U) == STATUS_OK);
    CHECK(bst_search(&t, 20U) == NULL);
    CHECK(t.count == 6U);
    (void)bst_inorder(&t, collect, &c);
    CHECK(c.n == 6U);
    bst_destroy(&t);
}

static void test_delete_one_child(void)
{
    bst_t t; const station_id_t in[] = {50U, 30U, 20U};   /* 30 has one child */
    bst_init(&t); fill(&t, in, 3U);
    CHECK(bst_delete(&t, 30U) == STATUS_OK);
    CHECK(bst_search(&t, 20U) != NULL);
    CHECK(t.root->left != NULL && t.root->left->data.id == 20U);
    bst_destroy(&t);
    bst_init(&t);
    { const station_id_t in2[] = {50U, 70U, 80U};          /* only right child */
      fill(&t, in2, 3U); }
    CHECK(bst_delete(&t, 70U) == STATUS_OK);
    CHECK(t.root->right != NULL && t.root->right->data.id == 80U);
    bst_destroy(&t);
}

static void test_delete_two_children(void)
{
    bst_t t; collect_t c; size_t i;
    bst_init(&t); c.n = 0U; fill(&t, SHAPE, 7U);
    CHECK(bst_delete(&t, 30U) == STATUS_OK);               /* successor 40 */
    CHECK(bst_search(&t, 30U) == NULL);
    CHECK(t.root->left->data.id == 40U);
    CHECK(t.count == 6U);
    (void)bst_inorder(&t, collect, &c);
    for (i = 1U; i < c.n; i++) { CHECK(c.ids[i - 1U] < c.ids[i]); }
    bst_destroy(&t);
}

static void test_delete_root(void)
{
    bst_t t; collect_t c; size_t i;
    bst_init(&t); c.n = 0U; fill(&t, SHAPE, 7U);
    CHECK(bst_delete(&t, 50U) == STATUS_OK);               /* successor 60 */
    CHECK(t.root != NULL && t.root->data.id == 60U);
    CHECK(bst_search(&t, 50U) == NULL);
    (void)bst_inorder(&t, collect, &c);
    CHECK(c.n == 6U);
    for (i = 1U; i < c.n; i++) { CHECK(c.ids[i - 1U] < c.ids[i]); }
    /* delete the remaining nodes one by one until the tree is empty */
    CHECK(bst_delete(&t, 60U) == STATUS_OK);
    CHECK(bst_delete(&t, 30U) == STATUS_OK);
    CHECK(bst_delete(&t, 70U) == STATUS_OK);
    CHECK(bst_delete(&t, 20U) == STATUS_OK);
    CHECK(bst_delete(&t, 40U) == STATUS_OK);
    CHECK(bst_delete(&t, 80U) == STATUS_OK);
    CHECK(t.root == NULL && t.count == 0U);
    CHECK(bst_delete(&t, 80U) == STATUS_ERR_NOT_FOUND);
}

static void test_delete_successor_is_direct_right_child(void)
{
    bst_t t; const station_id_t in[] = {50U, 30U, 70U, 80U};
    bst_init(&t); fill(&t, in, 4U);
    CHECK(bst_delete(&t, 50U) == STATUS_OK);               /* successor 70 */
    CHECK(t.root->data.id == 70U && t.root->right->data.id == 80U);
    CHECK(t.root->left->data.id == 30U);
    bst_destroy(&t);
}

static void test_stats_and_empty(void)
{
    bst_t t; uint32_t n = 99U; station_id_t mn = 5U; station_id_t mx = 5U;
    bst_init(&t);
    CHECK(bst_stats(&t, &n, &mn, &mx) == STATUS_ERR_EMPTY);
    CHECK(n == 0U && mn == 0U && mx == 0U);
    fill(&t, SHAPE, 7U);
    CHECK(bst_stats(&t, &n, &mn, &mx) == STATUS_OK);
    CHECK(n == 7U && mn == 20U && mx == 80U);
    bst_destroy(&t);
}

static void test_empty_tree_operations(void)
{
    bst_t t; collect_t c; c.n = 0U;
    bst_init(&t);
    CHECK(bst_inorder(&t, collect, &c) == STATUS_OK && c.n == 0U);
    CHECK(bst_preorder(&t, collect, &c) == STATUS_OK && c.n == 0U);
    CHECK(bst_delete(&t, 1U) == STATUS_ERR_NOT_FOUND);
    bst_destroy(&t);                                        /* safe on empty */
    bst_destroy(NULL);
}

static void test_preorder_order(void)
{
    bst_t t; collect_t c; c.n = 0U;
    bst_init(&t); fill(&t, SHAPE, 7U);
    CHECK(bst_preorder(&t, collect, &c) == STATUS_OK);
    CHECK(c.n == 7U && c.ids[0] == 50U && c.ids[1] == 30U && c.ids[2] == 20U);
    CHECK(c.ids[3] == 40U && c.ids[4] == 70U && c.ids[5] == 60U && c.ids[6] == 80U);
    bst_destroy(&t);
}

static void test_invalid_input(void)
{
    bst_t t; station_t bad; station_t ok = mk(1U);
    bst_init(&t);
    CHECK(bst_insert(NULL, &ok) == STATUS_ERR_NULL);
    CHECK(bst_insert(&t, NULL) == STATUS_ERR_NULL);
    CHECK(bst_delete(NULL, 1U) == STATUS_ERR_NULL);
    CHECK(bst_update(NULL, 1U, "a", 1U, 100U, 1U, "b") == STATUS_ERR_NULL);
    CHECK(bst_inorder(NULL, collect, NULL) == STATUS_ERR_NULL);
    CHECK(bst_inorder(&t, NULL, NULL) == STATUS_ERR_NULL);
    CHECK(bst_preorder(NULL, collect, NULL) == STATUS_ERR_NULL);
    CHECK(bst_stats(NULL, NULL, NULL, NULL) == STATUS_ERR_NULL);
    (void)memset(&bad, 0, sizeof(bad));
    bad.id = 0U;                                            /* out-of-range ID */
    CHECK(bst_insert(&t, &bad) == STATUS_ERR_RANGE);
    CHECK(t.count == 0U);
    bst_init(NULL);
}

static void test_capacity_limit(void)
{
    bst_t t; station_id_t id; status_t rc = STATUS_OK; collect_t *c;
    bst_init(&t);
    for (id = 1U; id <= BST_MAX_STATIONS; id++) {          /* degenerate (sorted) tree */
        station_t s = mk(id);
        rc = bst_insert(&t, &s);
        if (rc != STATUS_OK) { break; }
    }
    CHECK(rc == STATUS_OK && t.count == BST_MAX_STATIONS);
    { station_t s = mk(5000U); CHECK(bst_insert(&t, &s) == STATUS_ERR_FULL); }
    c = (collect_t *)malloc(sizeof(*c));
    CHECK(c != NULL);
    if (c != NULL) {
        c->n = 0U;
        CHECK(bst_inorder(&t, collect, c) == STATUS_OK && c->n == BST_MAX_STATIONS);
        c->n = 0U;
        CHECK(bst_preorder(&t, collect, c) == STATUS_OK && c->n == BST_MAX_STATIONS);
        free(c);
    }
    bst_destroy(&t);                                        /* deep tree teardown */
    CHECK(t.count == 0U);
}

int main(void)
{
    RUN_TEST(test_insert_empty);
    RUN_TEST(test_insert_multiple_and_inorder_sorted);
    RUN_TEST(test_duplicate_rejected);
    RUN_TEST(test_search);
    RUN_TEST(test_update);
    RUN_TEST(test_delete_leaf);
    RUN_TEST(test_delete_one_child);
    RUN_TEST(test_delete_two_children);
    RUN_TEST(test_delete_root);
    RUN_TEST(test_delete_successor_is_direct_right_child);
    RUN_TEST(test_stats_and_empty);
    RUN_TEST(test_empty_tree_operations);
    RUN_TEST(test_preorder_order);
    RUN_TEST(test_invalid_input);
    RUN_TEST(test_capacity_limit);
    return TEST_SUMMARY();
}
