# Test Report

Executed on Ubuntu 24.04, GCC 13, `make test` (flags: `-std=c11 -O2 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wstrict-prototypes`).

| Suite | Test cases | Checks | Failed |
|---|---:|---:|---:|
| `test_bst` | 15 | 98 | 0 |
| `test_station` (station, input, storage, functional) | 11 | 146 | 0 |
| `test_sliding_window` | 22 | 620 | 0 |
| `test_logger` (timestamps + logging, **new**) | 48 | 171 | 0 |
| `test_extended` (extended regression, **new**) | 189 | 280 | 0 |
| **Total** | **285** | **1315** | **0** |

**237 test cases were added** (the original suite had 48).

## What the new suites cover
| Area | Cases | Examples |
|---|---:|---|
| Timestamp formatting / logging (`test_logger.c`) | 48 | exact UTC output for known epochs (1970, 2000 leap day, 2001, 2038), ms zero-padding, buffer too small / NULL, level filtering, log-forging (CR/LF) sanitising, truncation, file + console sinks, append across sessions, injectable clock, timestamp on every simulation log line, `started_at`/`finished_at` in stats |
| Station validation | 22 | id/name/type/number boundaries, each illegal character class |
| Input parsing + prompts | 24 | signs, hex, exponent, overflow, blanks, retry limit, EOF |
| BST | 24 | all delete shapes, update atomicity, traversal order, stats, chain insert |
| Packets, sequence numbers, queues | 26 | mod-16 distance, checksum tamper detection per field, FIFO/due-tick/full/wrap-around |
| Go-Back-N sender / receiver | 34 | window flow control, cumulative/stale ACK, timer restart, retry limit, wrap over many rounds, duplicate vs out-of-order |
| Configuration + simulation | 30 | lossless for windows 1/2/7/15, 1000 packets, periodic loss, total loss -> `MAX_RETRIES`, seeded random loss, determinism, stat invariants |
| Storage + status strings | 26 | header, preorder, round-trip, comments/CRLF, every malformed-file class, all-or-nothing load |

Note found while writing the tests: a strictly periodic "drop every Nth transmission" pattern (e.g. N=2) can starve one packet
forever; the engine correctly stops with `STATUS_ERR_MAX_RETRIES` instead of looping (covered by
`test_x_sim_data_loss_every_2_starves_and_aborts`).

## Other runs in this workspace
* `make sanitize` (AddressSanitizer + UBSan) on all five C test binaries: clean.
* ThreadSanitizer on 4 parallel timestamped simulations: clean.
* C++17 compile check of all public headers (needed by the GoogleTest sources): OK.
* GoogleTest, Valgrind, Helgrind: **not run** here (not installed, no network). Run `make gtest valgrind helgrind` on your machine.

Run: `make test` (output ends with `ALL TEST SUITES PASSED`).
